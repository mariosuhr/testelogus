package com.logus.controller.exception;

public record ApiError(String mensagem) {
}